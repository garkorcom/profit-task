import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, onAuthStateChanged, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { auth } from '../firebase/firebase';
import { Employee, getEmployeeLinkByAuthUid } from '../api/employeeApi';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase/firebase';


interface AuthContextType {
  currentUser: User | null;
  loading: boolean;
  isCurrentUserAdmin: boolean;
  employeeData: Employee | null; // Данные сотрудника из Firestore
  ownerUid: string | null; // UID владельца данных
}

const AuthContext = createContext<AuthContextType>({ 
    currentUser: null, 
    loading: true, 
    isCurrentUserAdmin: false,
    employeeData: null,
    ownerUid: null
});

export const useAuth = () => useContext(AuthContext);

export const login = () => {
  const provider = new GoogleAuthProvider();
  return signInWithPopup(auth, provider);
};

export const logout = () => signOut(auth);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [employeeData, setEmployeeData] = useState<Employee | null>(null);
  const [ownerUid, setOwnerUid] = useState<string | null>(null);
  const [isCurrentUserAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      
      if (user) {
        // После входа пользователя, пытаемся найти его связь в employeeAuthLinks
        const link = await getEmployeeLinkByAuthUid(user.uid);
        if (link) {
            setOwnerUid(link.ownerUid);
            // Загружаем полные данные сотрудника
            const employeeRef = doc(db, `users/${link.ownerUid}/employees`, link.employeeId);
            const employeeSnap = await getDoc(employeeRef);
            if (employeeSnap.exists()) {
                const empData = { id: employeeSnap.id, ...employeeSnap.data() } as Employee;
                setEmployeeData(empData);
                // Проверяем, является ли он админом
                setIsAdmin(empData.role === 'admin');
            }
        } else {
            // Если связи нет, возможно, это сам владелец/админ
            // Проверим, есть ли у него самого запись в своих сотрудниках с ролью admin
            const selfEmployeeRef = doc(db, `users/${user.uid}/employees`, user.uid); // Предполагаем, что админ может быть сам себе сотрудником
            const selfEmployeeSnap = await getDoc(selfEmployeeRef);
            if(selfEmployeeSnap.exists() && selfEmployeeSnap.data().role === 'admin') {
                setIsAdmin(true);
                setOwnerUid(user.uid);
                setEmployeeData({ id: selfEmployeeSnap.id, ...selfEmployeeSnap.data() } as Employee);
            } else {
                // Если нет ни связи, ни админской записи - это обычный пользователь без доступа
                setIsAdmin(false);
                setEmployeeData(null);
                setOwnerUid(null);
            }
        }
      } else {
        // Пользователь не авторизован
        setIsAdmin(false);
        setEmployeeData(null);
        setOwnerUid(null);
      }
      
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  return (
    <AuthContext.Provider value={{ currentUser, loading, isCurrentUserAdmin, employeeData, ownerUid }}>
      {children}
    </AuthContext.Provider>
  );
};