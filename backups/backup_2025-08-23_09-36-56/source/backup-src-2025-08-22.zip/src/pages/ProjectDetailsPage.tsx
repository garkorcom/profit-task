import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Box, Typography, Tabs, Tab, Alert, Chip, Button, Dialog, DialogTitle, DialogContent, FormControl, InputLabel, Select, MenuItem, TextField, DialogActions, List, ListItem, ListItemText, IconButton } from '@mui/material';
import { GridLegacy as Grid } from '@mui/material';
import { ArrowBack as ArrowBackIcon, Business as BusinessIcon, CalendarToday as CalendarIcon, AttachMoney as MoneyIcon, Add as AddIcon } from '@mui/icons-material';
import { useAuth } from '../auth/AuthContext';
import { Project, getProjectStream } from '../api/projectApi';
import { Employee, getEmployeesStream, TimesheetEntry, getTimesheetsByProjectStream, addTimesheetEntry } from '../api/employeeApi';
import LoadingSpinner from '../components/common/LoadingSpinner';

const ProjectDetailsPage: React.FC = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState(0);
  const [timesheet, setTimesheet] = useState<TimesheetEntry[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [timeDialogOpen, setTimeDialogOpen] = useState(false);
  const [timeForm, setTimeForm] = useState<Partial<TimesheetEntry>>({ date: new Date().toISOString().slice(0, 10), hours: 1 });

  useEffect(() => {
    if (!currentUser || !projectId) {
      setLoading(false);
      setError("Проект не найден.");
      return;
    }

    const unsubscribe = getProjectStream(currentUser.uid, projectId, (data) => {
      if (data) {
        setProject(data);
      } else {
        setError("Проект не найден или у вас нет доступа.");
      }
      setLoading(false);
    });

    const unsubTimesheet = getTimesheetsByProjectStream(currentUser.uid, projectId, setTimesheet);
    const unsubEmployees = getEmployeesStream(currentUser.uid, setEmployees);

    return () => {
      unsubscribe();
      unsubTimesheet();
      unsubEmployees();
    };
  }, [currentUser, projectId]);

  const totalHours = useMemo(() => {
    return timesheet.reduce((sum, entry) => sum + (entry.hours || 0), 0);
  }, [timesheet]);

  const handleAddTimeEntry = async () => {
    if (!currentUser || !projectId || !project || !timeForm.employeeId || !timeForm.hours) return;
    const employee = employees.find(e => e.id === timeForm.employeeId);
    if (!employee) return;

    const newEntry: Omit<TimesheetEntry, 'id' | 'createdAt'> = {
      ...timeForm,
      projectId,
      projectName: project.name,
      employeeName: employee.fullName,
      hours: Number(timeForm.hours),
    } as any;
    
    await addTimesheetEntry(currentUser.uid, newEntry);
    setTimeDialogOpen(false);
    setTimeForm({ date: new Date().toISOString().slice(0, 10), hours: 1 });
  };

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <Alert severity="error">{error}</Alert>;
  if (!project) return <Alert severity="warning">Проект не найден.</Alert>;

  return (
    <Box>
      <Button startIcon={<ArrowBackIcon />} onClick={() => navigate('/projects')} sx={{ mb: 2 }}>
        К списку проектов
      </Button>
      
      <Typography variant="h4" gutterBottom>{project.name}</Typography>
      <Typography variant="body1" color="text.secondary" mb={2}>{project.description}</Typography>
      
      <Grid container spacing={2} mb={3}>
        <Grid item xs={12} md={4}>
          <Chip icon={<BusinessIcon />} label={`Клиент: ${project.contractorName}`} />
        </Grid>
        <Grid item xs={12} md={4}>
          <Chip icon={<CalendarIcon />} label={`Сроки: ${project.startDate} - ${project.endDate || '...'}`} />
        </Grid>
        <Grid item xs={12} md={4}>
          <Chip icon={<MoneyIcon />} label={`Бюджет: ${project.budget || 0} ₽ / Факт: ${project.actualCost || 0} ₽`} color={ (project.actualCost || 0) > (project.budget || 0) ? 'error' : 'success'} />
        </Grid>
        <Grid item xs={12}>
          <Chip label={`Затрачено часов: ${totalHours}`} variant="outlined" />
        </Grid>
      </Grid>
      
      <Tabs value={activeTab} onChange={handleTabChange} sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tab label="Обзор" />
        <Tab label="Задачи" />
        <Tab label="Сметы" />
        <Tab label="Финансы" />
        <Tab label="Документы" />
        <Tab label="Учет времени" />
      </Tabs>
      
      <Box mt={3}>
        {activeTab === 0 && <Typography>Обзор проекта...</Typography>}
        {activeTab === 1 && <Typography>Задачи проекта...</Typography>}
        {activeTab === 2 && <Typography>Сметы проекта...</Typography>}
        {activeTab === 3 && <Typography>Финансы проекта...</Typography>}
        {activeTab === 4 && <Typography>Документы проекта...</Typography>}
        {activeTab === 5 && (
          <Box>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="h6">Затраченное время</Typography>
              <Button variant="contained" startIcon={<AddIcon />} onClick={() => setTimeDialogOpen(true)}>
                Добавить время
              </Button>
            </Box>
            <List>
              {timesheet.map(entry => (
                <ListItem key={entry.id} divider>
                  <ListItemText 
                    primary={`${entry.employeeName} - ${entry.hours} ч.`}
                    secondary={`${entry.date} - ${entry.description || 'Без описания'}`}
                  />
                </ListItem>
              ))}
            </List>
          </Box>
        )}
      </Box>

      <Dialog open={timeDialogOpen} onClose={() => setTimeDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Добавить запись о времени</DialogTitle>
        <DialogContent>
          <Box display="flex" flexDirection="column" gap={2} pt={1}>
            <FormControl fullWidth>
              <InputLabel>Сотрудник</InputLabel>
              <Select
                value={timeForm.employeeId || ''}
                label="Сотрудник"
                onChange={(e) => setTimeForm({ ...timeForm, employeeId: e.target.value })}
              >
                {employees.map(e => (
                  <MenuItem key={e.id} value={e.id}>{e.fullName}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <TextField
              label="Дата"
              type="date"
              value={timeForm.date}
              onChange={(e) => setTimeForm({ ...timeForm, date: e.target.value })}
              InputLabelProps={{ shrink: true }}
            />
            <TextField
              label="Часы"
              type="number"
              value={timeForm.hours}
              onChange={(e) => setTimeForm({ ...timeForm, hours: Number(e.target.value) })}
            />
            <TextField
              label="Описание работ"
              multiline
              rows={2}
              value={timeForm.description || ''}
              onChange={(e) => setTimeForm({ ...timeForm, description: e.target.value })}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setTimeDialogOpen(false)}>Отмена</Button>
          <Button onClick={handleAddTimeEntry} variant="contained">Сохранить</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ProjectDetailsPage;
