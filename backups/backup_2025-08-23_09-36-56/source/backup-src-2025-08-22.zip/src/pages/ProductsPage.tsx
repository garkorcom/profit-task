import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
  Chip,
  Alert,
  Tab,
  Tabs,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  InputAdornment,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Tooltip,
  ToggleButtonGroup,
  ToggleButton,
  Autocomplete
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  AddCircle as IncomeIcon,
  RemoveCircle as ExpenseIcon,
  Warning as WarningIcon,
  Search as SearchIcon,
  History as HistoryIcon,
  Category as CategoryIcon,
  Remove as RemoveIcon,
  Calculate as CalculateIcon
} from '@mui/icons-material';
import { useAuth } from '../auth/AuthContext';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ConfirmDialog from '../components/common/ConfirmDialog';
import Notification from '../components/common/Notification';
import {
  Product,
  ProductComponent,
  StockMovement,
  getProductsStream,
  getCriticalStockProducts,
  getStockMovementsStream,
  addProduct,
  updateProduct,
  deleteProduct,
  addStock,
  removeStock,
  calculateServiceCostPrice
} from '../api/productApi';

const StockIndicator: React.FC<{ current: number; min?: number; reserved?: number }> = ({ 
  current, 
  min = 0, 
  reserved = 0 
}) => {
  const available = current - reserved;
  const isCritical = min > 0 && available <= min;
  const isOut = available <= 0;
  
  if (isNaN(current)) return null;

  return (
    <Box display="flex" alignItems="center" gap={1}>
      <Typography variant="body2" color={isOut ? 'error' : isCritical ? 'warning.main' : 'text.primary'}>
        Остаток: {current}
      </Typography>
      {reserved > 0 && (
        <Chip 
          label={`Резерв: ${reserved}`} 
          size="small" 
          color="info" 
          variant="outlined" 
        />
      )}
      {available !== current && (
        <Chip 
          label={`Доступно: ${available}`} 
          size="small" 
          color={isOut ? 'error' : isCritical ? 'warning' : 'success'} 
        />
      )}
      {isCritical && <WarningIcon color="warning" fontSize="small" />}
    </Box>
  );
};

const ProductsPage: React.FC = () => {
  const { currentUser } = useAuth();
  
  const [products, setProducts] = useState<Product[]>([]);
  const [criticalProducts, setCriticalProducts] = useState<Product[]>([]);
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(0);
  
  const [productDialog, setProductDialog] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [movementDialog, setMovementDialog] = useState(false);
  const [movementType, setMovementType] = useState<'income' | 'expense'>('income');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  const [productForm, setProductForm] = useState<Partial<Product>>({
    name: '',
    type: 'product',
    sku: '',
    unit: 'шт',
    category: '',
    minStock: 0,
    currentStock: 0,
    costPrice: 0,
    salePrice: 0,
    supplier: '',
    description: ''
  });
  
  const [movementForm, setMovementForm] = useState({
    quantity: 1,
    document: '',
    comment: ''
  });
  
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  
  const [notification, setNotification] = useState<{
    open: boolean;
    message: string;
    severity: 'success' | 'error' | 'warning' | 'info';
  }>({ open: false, message: '', severity: 'success' });
  
  const [confirmDelete, setConfirmDelete] = useState<Product | null>(null);

  useEffect(() => {
    if (!currentUser) return;
    
    const unsubProducts = getProductsStream(currentUser.uid, (data) => {
      setProducts(data);
      setLoading(false);
    });
    
    const unsubCritical = getCriticalStockProducts(currentUser.uid, setCriticalProducts);
    
    const unsubMovements = getStockMovementsStream(currentUser.uid, undefined, (data) => {
      setMovements(data.slice(0, 50)); 
    });
    
    return () => {
      unsubProducts();
      unsubCritical();
      unsubMovements();
    };
  }, [currentUser]);

  const handleOpenProductDialog = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
      setProductForm({ ...product });
    } else {
      setEditingProduct(null);
      setProductForm({
        name: '',
        type: 'product',
        sku: '',
        unit: 'шт',
        category: '',
        minStock: 0,
        currentStock: 0,
        costPrice: 0,
        salePrice: 0,
        supplier: '',
        description: ''
      });
    }
    setProductDialog(true);
  };

  const handleCloseProductDialog = () => {
    setProductDialog(false);
    setEditingProduct(null);
  };

  const handleSaveProduct = async () => {
    if (!currentUser || !productForm.name || !productForm.unit) return;
    
    try {
      if (editingProduct) {
        // Pass `true` to recalculate cost price if it's a service
        const shouldRecalculate = productForm.type === 'service';
        await updateProduct(currentUser.uid, editingProduct.id, productForm, shouldRecalculate, products);
        
        setNotification({ open: true, message: 'Позиция успешно обновлена', severity: 'success' });
      } else {
        await addProduct(currentUser.uid, productForm as Omit<Product, 'id'>);
        setNotification({ open: true, message: 'Позиция успешно добавлена', severity: 'success' });
      }
      handleCloseProductDialog();
    } catch (error) {
      console.error('Ошибка при сохранении:', error);
      setNotification({ open: true, message: 'Ошибка при сохранении', severity: 'error' });
    }
  };

  const handleDeleteProduct = async (product: Product) => {
    if (!currentUser) return;
    try {
      await deleteProduct(currentUser.uid, product.id);
      setNotification({ open: true, message: 'Позиция удалена', severity: 'success' });
    } catch (error) {
      setNotification({ open: true, message: 'Ошибка при удалении', severity: 'error' });
    }
    setConfirmDelete(null);
  };

  const handleOpenMovementDialog = (type: 'income' | 'expense', product?: Product) => {
    setMovementType(type);
    setSelectedProduct(product || null);
    setMovementForm({ quantity: 1, document: '', comment: '' });
    setMovementDialog(true);
  };

  const handleCloseMovementDialog = () => {
    setMovementDialog(false);
    setSelectedProduct(null);
  };


  const handleAddComponent = (component: Product) => {
    if (!component) return;
    const newComponent: ProductComponent = {
      productId: component.id,
      name: component.name,
      quantity: 1,
      unit: component.unit,
    };
    const updatedComponents = [...(productForm.components || []), newComponent];
    setProductForm({ ...productForm, components: updatedComponents });
  };

  const handleUpdateComponentQuantity = (index: number, quantity: number) => {
    const updatedComponents = [...(productForm.components || [])];
    updatedComponents[index].quantity = quantity;
    setProductForm({ ...productForm, components: updatedComponents });
  };
  
  const handleRemoveComponent = (index: number) => {
    const updatedComponents = [...(productForm.components || [])];
    updatedComponents.splice(index, 1);
    setProductForm({ ...productForm, components: updatedComponents });
  };

  const handleRecalculateCostPrice = () => {
    if (productForm.type === 'service') {
      const calculatedCost = calculateServiceCostPrice(productForm as Product, products);
      setProductForm({ ...productForm, costPrice: calculatedCost });
    }
  };


  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) || (product.sku && product.sku.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = !categoryFilter || product.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const categories = Array.from(new Set(products.map(p => p.category).filter(Boolean)));

  const getMovementTypeLabel = (type: string) => {
    const labels = { income: 'Приход', expense: 'Расход', reserve: 'Резерв', unreserve: 'Снятие резерва' };
    return labels[type as keyof typeof labels] || type;
  };

  if (loading) return <LoadingSpinner />;

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4"><CategoryIcon sx={{ mr: 1, verticalAlign: 'middle' }} />Товары и Услуги</Typography>
        <Box display="flex" gap={1}>
          <Button variant="outlined" startIcon={<IncomeIcon />} onClick={() => handleOpenMovementDialog('income')} color="success">Приход</Button>
          <Button variant="outlined" startIcon={<ExpenseIcon />} onClick={() => handleOpenMovementDialog('expense')} color="error">Расход</Button>
          <Button variant="contained" startIcon={<AddIcon />} onClick={() => handleOpenProductDialog()}>Новая позиция</Button>
        </Box>
      </Box>

      {criticalProducts.length > 0 && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          <Typography variant="subtitle2" gutterBottom>Критические остатки ({criticalProducts.length}):</Typography>
          <Box display="flex" flexWrap="wrap" gap={1}>
            {criticalProducts.map(p => (<Chip key={p.id} label={`${p.name}: ${p.availableStock}/${p.minStock} ${p.unit}`} color="warning" size="small" onClick={() => handleOpenMovementDialog('income', p)} />))}
          </Box>
        </Alert>
      )}

      <Tabs value={activeTab} onChange={(_, v) => setActiveTab(v)} sx={{ mb: 2 }}>
        <Tab label={`Все (${products.length})`} icon={<CategoryIcon />} iconPosition="start" />
        <Tab label="История движений" icon={<HistoryIcon />} iconPosition="start" />
      </Tabs>

      {activeTab === 0 && (
        <>
          <Box display="flex" gap={2} mb={2}>
            <TextField placeholder="Поиск..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} InputProps={{ startAdornment: (<InputAdornment position="start"><SearchIcon /></InputAdornment>) }} sx={{ flexGrow: 1 }} />
            <FormControl sx={{ minWidth: 200 }}>
              <InputLabel>Категория</InputLabel>
              <Select value={categoryFilter} label="Категория" onChange={(e) => setCategoryFilter(e.target.value)}>
                <MenuItem value="">Все</MenuItem>
                {categories.map(cat => (<MenuItem key={cat} value={cat}>{cat}</MenuItem>))}
              </Select>
            </FormControl>
          </Box>

          {!filteredProducts.length ? (
            <Card><CardContent><Typography color="text.secondary" align="center">Ничего не найдено</Typography></CardContent></Card>
          ) : (
            <Box display="flex" flexWrap="wrap" gap={2}>
              {filteredProducts.map(p => (
                <Box key={p.id} sx={{ width: { xs: '100%', md: 'calc(50% - 8px)', lg: 'calc(33.333% - 11px)' } }}>
                  <Card>
                    <CardContent>
                      <Box display="flex" justifyContent="space-between" mb={1}>
                        <Box>
                          <Typography variant="h6">{p.name}</Typography>
                          <Chip label={p.type === 'service' ? 'Услуга' : 'Товар'} size="small" color={p.type === 'service' ? 'secondary' : 'primary'} sx={{ mr: 1 }} />
                          {p.sku && <Typography variant="caption" color="text.secondary">Артикул: {p.sku}</Typography>}
                        </Box>
                        <Box>
                          {p.type === 'product' && <Tooltip title="Приход/Расход"><IconButton size="small" onClick={() => handleOpenMovementDialog('income', p)}><IncomeIcon fontSize="small" color="success" /></IconButton></Tooltip>}
                          <IconButton size="small" onClick={() => handleOpenProductDialog(p)}><EditIcon fontSize="small" /></IconButton>
                          <IconButton size="small" color="error" onClick={() => setConfirmDelete(p)}><DeleteIcon fontSize="small" /></IconButton>
                        </Box>
                      </Box>
                      {p.type === 'product' && <StockIndicator current={p.currentStock} min={p.minStock} reserved={p.reservedStock} />}
                      <Box mt={2}>
                        <Typography variant="body2" color="text.secondary">Единица: {p.unit}</Typography>
                        {p.salePrice && <Typography variant="body2" color="text.secondary">Цена продажи: {p.salePrice} ₽</Typography>}
                      </Box>
                    </CardContent>
                  </Card>
                </Box>
              ))}
            </Box>
          )}
        </>
      )}

      {activeTab === 1 && (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Дата</TableCell><TableCell>Товар</TableCell><TableCell>Операция</TableCell>
                <TableCell align="right">Количество</TableCell><TableCell align="right">Было → Стало</TableCell><TableCell>Комментарий</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {!movements.length ? (
                <TableRow><TableCell colSpan={6} align="center"><Typography color="text.secondary">История пуста</Typography></TableCell></TableRow>
              ) : (
                movements.map(m => (
                  <TableRow key={m.id}>
                    <TableCell>{m.createdAt?.toDate?.().toLocaleString('ru-RU') || 'Н/Д'}</TableCell>
                    <TableCell>{m.productName}</TableCell>
                    <TableCell><Chip label={getMovementTypeLabel(m.type)} size="small" color={m.quantity > 0 ? 'success' : 'error'} /></TableCell>
                    <TableCell align="right"><Typography color={m.quantity > 0 ? 'success.main' : 'error.main'}>{m.quantity > 0 ? '+' : ''}{m.quantity}</Typography></TableCell>
                    <TableCell align="right">{m.previousStock} → {m.newStock}</TableCell>
                    <TableCell>{m.comment}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      <Dialog open={productDialog} onClose={handleCloseProductDialog} maxWidth="sm" fullWidth>
        <DialogTitle>{editingProduct ? 'Редактировать позицию' : 'Новая позиция'}</DialogTitle>
        <DialogContent>
          <Box display="flex" flexDirection="column" gap={2} mt={1}>
            <ToggleButtonGroup value={productForm.type} exclusive onChange={(e, v) => v && setProductForm({ ...productForm, type: v })} fullWidth sx={{ mb: 1 }}>
              <ToggleButton value="product">Товар</ToggleButton>
              <ToggleButton value="service">Услуга</ToggleButton>
            </ToggleButtonGroup>
            <TextField label="Название" value={productForm.name || ''} onChange={e => setProductForm({ ...productForm, name: e.target.value })} required fullWidth />
            <Box display="flex" gap={2}>
              <TextField label="Артикул" value={productForm.sku || ''} onChange={e => setProductForm({ ...productForm, sku: e.target.value })} fullWidth />
              <FormControl fullWidth required><InputLabel>Ед. изм.</InputLabel><Select value={productForm.unit || 'шт'} label="Ед. изм." onChange={e => setProductForm({ ...productForm, unit: e.target.value })}><MenuItem value="шт">шт</MenuItem><MenuItem value="кг">кг</MenuItem><MenuItem value="л">л</MenuItem><MenuItem value="м">м</MenuItem></Select></FormControl>
            </Box>
            {productForm.type === 'product' && (
              <Box display="flex" gap={2}>
                {!editingProduct && <TextField label="Начальный остаток" type="number" value={productForm.currentStock || 0} onChange={e => setProductForm({ ...productForm, currentStock: Number(e.target.value) })} fullWidth />}
                <TextField label="Мин. остаток" type="number" value={productForm.minStock || 0} onChange={e => setProductForm({ ...productForm, minStock: Number(e.target.value) })} fullWidth helperText="Для уведомлений" />
              </Box>
            )}
            <TextField label="Цена продажи" type="number" value={productForm.salePrice || 0} onChange={e => setProductForm({ ...productForm, salePrice: Number(e.target.value) })} fullWidth InputProps={{ endAdornment: <InputAdornment position="end">₽</InputAdornment> }} />
            <TextField label="Описание" value={productForm.description || ''} onChange={e => setProductForm({ ...productForm, description: e.target.value })} multiline rows={2} fullWidth />
            
            {productForm.type === 'service' && (
              <Box mt={2}>
                <Typography variant="h6" gutterBottom>Состав услуги</Typography>
                <Autocomplete
                  options={products.filter(p => p.id !== editingProduct?.id && !productForm.components?.some(c => c.productId === p.id))}
                  getOptionLabel={(option) => `${option.name} (${option.costPrice || 0} ₽/${option.unit})`}
                  onChange={(e, value) => {
                    if (value) {
                      handleAddComponent(value);
                      // Clear the autocomplete after selection
                      setTimeout(() => {
                        const autocompleteInput = document.querySelector('[aria-label="Добавить компонент"]') as HTMLInputElement;
                        if (autocompleteInput) autocompleteInput.value = '';
                      }, 100);
                    }
                  }}
                  renderInput={(params) => <TextField {...params} label="Добавить компонент" aria-label="Добавить компонент" />}
                  value={null}
                />
                
                {(productForm.components || []).length > 0 && (
                  <TableContainer component={Paper} sx={{ mt: 2 }}>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell>Компонент</TableCell>
                          <TableCell align="right">Цена за ед.</TableCell>
                          <TableCell align="center">Кол-во</TableCell>
                          <TableCell align="right">Сумма</TableCell>
                          <TableCell width={50}></TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {(productForm.components || []).map((comp, index) => {
                          const componentProduct = products.find(p => p.id === comp.productId);
                          const unitCost = componentProduct?.costPrice || 0;
                          const totalCost = unitCost * comp.quantity;
                          
                          return (
                            <TableRow key={comp.productId}>
                              <TableCell>
                                <Typography variant="body2">{comp.name}</Typography>
                                <Typography variant="caption" color="text.secondary">{comp.unit}</Typography>
                              </TableCell>
                              <TableCell align="right">{unitCost} ₽</TableCell>
                              <TableCell align="center">
                                <Box display="flex" alignItems="center" justifyContent="center">
                                  <IconButton size="small" onClick={() => handleUpdateComponentQuantity(index, Math.max(1, comp.quantity - 1))}>
                                    <RemoveIcon fontSize="small" />
                                  </IconButton>
                                  <TextField 
                                    type="number"
                                    value={comp.quantity}
                                    onChange={(e) => handleUpdateComponentQuantity(index, Math.max(1, Number(e.target.value)))}
                                    sx={{ width: '60px', mx: 1 }}
                                    size="small"
                                    inputProps={{ min: 1, style: { textAlign: 'center' } }}
                                  />
                                  <IconButton size="small" onClick={() => handleUpdateComponentQuantity(index, comp.quantity + 1)}>
                                    <AddIcon fontSize="small" />
                                  </IconButton>
                                </Box>
                              </TableCell>
                              <TableCell align="right">
                                <Typography variant="body2" fontWeight="medium">{totalCost} ₽</Typography>
                              </TableCell>
                              <TableCell>
                                <IconButton size="small" color="error" onClick={() => handleRemoveComponent(index)}>
                                  <DeleteIcon fontSize="small" />
                                </IconButton>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </TableContainer>
                )}
                
                <Box mt={2} display="flex" gap={2} alignItems="flex-end">
                  <TextField 
                    label="Себестоимость услуги"
                    type="number"
                    value={productForm.costPrice || 0}
                    InputProps={{ 
                      readOnly: true, 
                      endAdornment: <InputAdornment position="end">₽</InputAdornment>,
                      sx: { fontWeight: 'bold' }
                    }}
                    fullWidth
                  />
                  <Button 
                    onClick={handleRecalculateCostPrice} 
                    variant="contained" 
                    color="primary"
                    startIcon={<CalculateIcon />}
                  >
                    Пересчитать
                  </Button>
                </Box>
                
                {productForm.salePrice && productForm.costPrice ? (
                  <Box mt={2} p={2} bgcolor="grey.50" borderRadius={1}>
                    <Typography variant="subtitle2" gutterBottom>Расчет прибыли:</Typography>
                    <Box display="flex" justifyContent="space-between">
                      <Typography variant="body2">Прибыль:</Typography>
                      <Typography variant="body2" color={productForm.salePrice - productForm.costPrice >= 0 ? 'success.main' : 'error.main'} fontWeight="medium">
                        {productForm.salePrice - productForm.costPrice} ₽
                      </Typography>
                    </Box>
                    <Box display="flex" justifyContent="space-between">
                      <Typography variant="body2">Маржинальность:</Typography>
                      <Typography variant="body2" fontWeight="medium">
                        {productForm.costPrice > 0 ? Math.round(((productForm.salePrice - productForm.costPrice) / productForm.salePrice) * 100) : 0}%
                      </Typography>
                    </Box>
                    <Box display="flex" justifyContent="space-between">
                      <Typography variant="body2">Наценка:</Typography>
                      <Typography variant="body2" fontWeight="medium">
                        {productForm.costPrice > 0 ? Math.round(((productForm.salePrice - productForm.costPrice) / productForm.costPrice) * 100) : 0}%
      </Typography>
                    </Box>
                  </Box>
                ) : null}
              </Box>
            )}

            {productForm.type === 'product' && (
              <TextField 
                label="Себестоимость"
                type="number"
                value={productForm.costPrice || 0}
                onChange={e => setProductForm({ ...productForm, costPrice: Number(e.target.value) })}
                fullWidth 
                InputProps={{ endAdornment: <InputAdornment position="end">₽</InputAdornment> }}
              />
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseProductDialog}>Отмена</Button>
          <Button onClick={handleSaveProduct} variant="contained" disabled={!productForm.name || !productForm.unit}>Сохранить</Button>
        </DialogActions>
      </Dialog>
      
      {/* ... (movement dialog, confirm dialog, notification) */}
      <ConfirmDialog open={!!confirmDelete} title="Удалить?" message={`Удалить "${confirmDelete?.name}"?`} onConfirm={() => confirmDelete && handleDeleteProduct(confirmDelete)} onClose={() => setConfirmDelete(null)} />
      <Notification open={notification.open} message={notification.message} severity={notification.severity} onClose={() => setNotification({ ...notification, open: false })} />
    </Box>
  );
};

export default ProductsPage;


