import React, { useState, useEffect } from 'react';
import { Box, Typography, Button, Paper, Alert, Divider } from '@mui/material';
import { useAuth } from '../auth/AuthContext';
import { getProjectsStream, Project } from '../api/projectApi';
import { getTasksStream, Task } from '../api/taskApi';
import StartWorkButton from '../components/StartWorkButton';

const TimeTrackingTestPage: React.FC = () => {
  const { currentUser } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [workSession, setWorkSession] = useState<any>(null);

  useEffect(() => {
    if (!currentUser) return;
    const unsubProjects = getProjectsStream(currentUser.uid, setProjects);
    const unsubTasks = getTasksStream(currentUser.uid, setTasks);
    
    // Check for active work session
    const session = localStorage.getItem('workSession');
    if (session) {
      setWorkSession(JSON.parse(session));
    }
    
    return () => { 
      unsubProjects && unsubProjects();
      unsubTasks && unsubTasks();
    };
  }, [currentUser]);

  const clearWorkSession = () => {
    localStorage.removeItem('workSession');
    setWorkSession(null);
  };

  if (!currentUser) {
    return <Typography>Пожалуйста, войдите в систему</Typography>;
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Тестирование модуля учета времени
      </Typography>

      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Информация о пользователе
        </Typography>
        <Typography>Email: {currentUser.email}</Typography>
        <Typography>UID: {currentUser.uid}</Typography>
      </Paper>

      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Статус системы
        </Typography>
        <Typography>Проектов загружено: {projects.length}</Typography>
        <Typography>Задач загружено: {tasks.length}</Typography>
        <Typography>Активных проектов: {projects.filter(p => p.status === 'active').length}</Typography>
        <Typography>Незавершенных задач: {tasks.filter(t => t.status !== 'completed').length}</Typography>
      </Paper>

      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Активная рабочая сессия
        </Typography>
        {workSession ? (
          <Box>
            <Alert severity="success" sx={{ mb: 2 }}>
              Идет учет времени!
            </Alert>
            <Typography>Проект: {workSession.projectName}</Typography>
            <Typography>Задача: {workSession.taskName}</Typography>
            <Typography>Начало: {new Date(workSession.startTime).toLocaleString('ru-RU')}</Typography>
            <Button 
              variant="outlined" 
              color="error" 
              onClick={clearWorkSession}
              sx={{ mt: 2 }}
            >
              Очистить сессию (для теста)
            </Button>
          </Box>
        ) : (
          <Alert severity="info">
            Нет активной рабочей сессии
          </Alert>
        )}
      </Paper>

      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Тест компонента StartWorkButton
        </Typography>
        <Box sx={{ mt: 2 }}>
          <StartWorkButton projects={projects} tasks={tasks} />
        </Box>
      </Paper>

      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Прямые ссылки для тестирования
        </Typography>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
          <Button 
            variant="outlined" 
            onClick={() => window.location.href = '/'}
          >
            Перейти на главную страницу
          </Button>
          <Button 
            variant="outlined" 
            onClick={() => window.location.href = '/employees'}
          >
            Перейти к списку сотрудников
          </Button>
          <Button 
            variant="outlined" 
            onClick={() => window.location.href = '/?startWork=1'}
          >
            Открыть главную с диалогом начала работы
          </Button>
        </Box>
      </Paper>

      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom>
          Проекты и задачи (для отладки)
        </Typography>
        <Divider sx={{ my: 2 }} />
        {projects.map(project => (
          <Box key={project.id} sx={{ mb: 2 }}>
            <Typography variant="subtitle1" fontWeight="bold">
              {project.name} ({project.status})
            </Typography>
            {tasks
              .filter(t => t.projectId === project.id)
              .map(task => (
                <Typography key={task.id} variant="body2" sx={{ ml: 2 }}>
                  - {task.name} ({task.status})
                </Typography>
              ))}
          </Box>
        ))}
      </Paper>
    </Box>
  );
};

export default TimeTrackingTestPage;
