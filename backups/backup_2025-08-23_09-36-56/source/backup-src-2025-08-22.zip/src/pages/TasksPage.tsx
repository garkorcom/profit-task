import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Card, 
  CardContent, 
  Button, 
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  Chip,
  FormHelperText
} from '@mui/material';
import { Delete as DeleteIcon, Edit as EditIcon, Business as BusinessIcon, Work as WorkIcon, AttachMoney as MoneyIcon } from '@mui/icons-material';
import { useAuth } from '../auth/AuthContext';
import LoadingSpinner from '../components/common/LoadingSpinner';
import Notification from '../components/common/Notification';
import ConfirmDialog from '../components/common/ConfirmDialog';
import TimeTrackingButton from '../components/TimeTrackingButton';
import { getTasksStream, addTask, updateTask, deleteTask, Task, TaskStatus, TaskPriority } from '../api/taskApi';
import { getContractorsStream, Contractor } from '../api/contractorApi';
import { getProjectsStream, Project } from '../api/projectApi';
import { useLocation, useNavigate } from 'react-router-dom';
import { storage } from '../firebase/firebase';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

const TasksPage: React.FC = () => {
  const { currentUser } = useAuth();
  const location = useLocation() as any;
  const navigate = useNavigate();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [contractors, setContractors] = useState<Contractor[]>([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    priority: 'medium',
    status: 'pending',
    contractorId: '',
    contractorName: '',
    projectId: '',
    projectName: '',
  });
  const [projects, setProjects] = useState<Project[]>([]);
  const [notification, setNotification] = useState<{
    open: boolean;
    message: string;
    severity: 'success' | 'error' | 'info' | 'warning';
  }>({
    open: false,
    message: '',
    severity: 'info'
  });
  const [submitting, setSubmitting] = useState(false);
  const [confirm, setConfirm] = useState<{ open: boolean; taskId?: string }>({ open: false });
  const [filterContractorId, setFilterContractorId] = useState<string>('');
  const [filterProjectId, setFilterProjectId] = useState<string>(''); // Фильтр по проекту
  const [startWorkData, setStartWorkData] = useState<{ open: boolean; task: Task | null; file: File | null; location: GeolocationPosition | null }>({ open: false, task: null, file: null, location: null });

  useEffect(() => {
    if (!currentUser) return;
    
    const unsubscribeTasks = getTasksStream(currentUser.uid, (data) => {
      setTasks(data);
    });
    
    const unsubscribeContractors = getContractorsStream(currentUser.uid, (data) => {
      setContractors(data);
    });
    const unsubscribeProjects = getProjectsStream(currentUser.uid, (data) => {
      setProjects(data);
      setLoading(false);
    });
    
    return () => {
      unsubscribeTasks();
      unsubscribeContractors();
      unsubscribeProjects();
    };
  }, [currentUser]);

  useEffect(() => {
    if (loading) return;
    const newForContractorId = location?.state?.newForContractorId as string | undefined;
    const newForProjectId = location?.state?.newForProjectId as string | undefined;
    
    if (newForContractorId) {
      const prefill = contractors.find(c => c.id === newForContractorId);
      setEditingTask(null);
      setFormData({
        name: '',
        description: '',
        priority: 'medium',
        status: 'pending',
        contractorId: prefill?.id || newForContractorId || '',
        contractorName: prefill?.name || '',
        projectId: filterProjectId || '',
        projectName: projects.find(p => p.id === filterProjectId)?.name || '',
      });
      setOpenDialog(true);
      setFilterContractorId(newForContractorId);
      navigate('/tasks', { replace: true, state: {} });
    } else if (newForProjectId) {
      const project = projects.find(p => p.id === newForProjectId);
      if (project) {
        setEditingTask(null);
        setFormData({
          name: '',
          description: '',
          priority: 'medium',
          status: 'pending',
          contractorId: project.contractorId || '',
          contractorName: project.contractorName || '',
          projectId: project.id,
          projectName: project.name,
        });
        setFilterProjectId(project.id);
        setOpenDialog(true);
        navigate('/tasks', { replace: true, state: {} });
      }
    }
  }, [loading, contractors, projects, location, navigate, filterProjectId]);

  const handleOpenDialog = (task?: Task) => {
    if (task) {
      setEditingTask(task);
      setFormData({
        name: task.name,
        description: task.description || '',
        priority: task.priority || 'medium',
        status: task.status || 'pending',
        contractorId: task.contractorId || '',
        contractorName: task.contractorName || '',
        projectId: (task as any).projectId || '',
        projectName: (task as any).projectName || '',
      });
    } else {
      setEditingTask(null);
      const prefillId = filterContractorId || '';
      const prefill = contractors.find(c => c.id === prefillId);
      setFormData({
        name: '',
        description: '',
        priority: 'medium',
        status: 'pending',
        contractorId: prefill?.id || '',
        contractorName: prefill?.name || '',
        projectId: filterProjectId || '',
        projectName: projects.find(p => p.id === filterProjectId)?.name || '',
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingTask(null);
    setFormData({
      name: '',
      description: '',
      priority: 'medium',
      status: 'pending',
      contractorId: '',
      contractorName: '',
      projectId: '',
      projectName: '',
    });
  };

  const handleSubmit = async () => {
    if (!currentUser || !formData.name?.trim() || !formData.contractorId) return;

    setSubmitting(true);
    try {
      const taskData = {
        ...formData,
        task: formData.name, // Переименовываем name в task
        status: formData.status as TaskStatus,
        priority: formData.priority as TaskPriority
      };

      if (editingTask) {
        await updateTask(currentUser.uid, editingTask.id, taskData);
        setNotification({ open: true, message: 'Задача успешно обновлена!', severity: 'success' });
      } else {
        await addTask(currentUser.uid, taskData);
        setNotification({ open: true, message: 'Задача успешно создана!', severity: 'success' });
      }
      handleCloseDialog();
    } catch (error) {
      console.error('Ошибка при сохранении задачи:', error);
      setNotification({ open: true, message: 'Произошла ошибка при сохранении задачи', severity: 'error' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleStartWork = async () => {
    if (!currentUser || !startWorkData.task || !startWorkData.file) return;

    try {
      // 1. Upload photo
      const photoRef = ref(storage, `tasks/${startWorkData.task.id}/start_${Date.now()}`);
      await uploadBytes(photoRef, startWorkData.file);
      const photoURL = await getDownloadURL(photoRef);

      // 2. Prepare location data
      const locationData = startWorkData.location ? {
        latitude: startWorkData.location.coords.latitude,
        longitude: startWorkData.location.coords.longitude,
      } : undefined;

      // 3. Update task
      await updateTask(currentUser.uid, startWorkData.task.id, {
        status: 'in_progress',
        startedAt: new Date(),
        startPhotoUrl: photoURL,
        startLocation: locationData,
      });

      setNotification({ open: true, message: 'Работа по задаче начата!', severity: 'success' });
      setStartWorkData({ open: false, task: null, file: null, location: null });
    } catch (error) {
      console.error("Failed to start work:", error);
      setNotification({ open: true, message: 'Ошибка при старте работ', severity: 'error' });
    }
  };

  const requestDelete = (taskId: string) => {
    setConfirm({ open: true, taskId });
  };

  const confirmDelete = async () => {
    if (!currentUser || !confirm.taskId) return;
    try {
      await deleteTask(currentUser.uid, confirm.taskId);
      setNotification({ open: true, message: 'Задача успешно удалена!', severity: 'success' });
    } catch (error) {
      console.error('Ошибка при удалении задачи:', error);
      setNotification({ open: true, message: 'Произошла ошибка при удалении задачи', severity: 'error' });
    } finally {
      setConfirm({ open: false });
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'error';
      case 'medium': return 'warning';
      case 'low': return 'success';
      default: return 'default';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'success';
      case 'in_progress': return 'warning';
      case 'pending': return 'info';
      default: return 'default';
    }
  };

  const handleContractorChange = (contractorId: string) => {
    const selectedContractor = contractors.find(c => c.id === contractorId);
    setFormData({
      ...formData,
      contractorId: contractorId,
      contractorName: selectedContractor?.name || '',
      projectId: '', // Сбрасываем проект при смене контрагента
      projectName: ''
    });
  };

  const visibleTasks = tasks.filter(t => 
    (!filterContractorId || t.contractorId === filterContractorId) &&
    (!filterProjectId || t.projectId === filterProjectId)
  );

  const isSaveDisabled = !formData.name?.trim() || !formData.contractorId || submitting || contractors.length === 0;

  if (loading) return <LoadingSpinner />;
  
  return (
    <Box>
      <Typography variant="h4" gutterBottom>Задачи</Typography>
      <Box display="flex" gap={2} alignItems="center" mb={2}>
        <Button 
          variant="contained" 
          onClick={() => handleOpenDialog()}
          disabled={contractors.length === 0}
        >
          + Новая задача
        </Button>
        <FormControl sx={{ minWidth: 240 }}>
          <InputLabel>Фильтр по контрагенту</InputLabel>
          <Select
            value={filterContractorId}
            label="Фильтр по контрагенту"
            onChange={(e) => setFilterContractorId(e.target.value)}
          >
            <MenuItem value="">
              <em>Все</em>
            </MenuItem>
            {contractors.map(c => (
              <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>
            ))}
          </Select>
        </FormControl>
        <FormControl sx={{ minWidth: 240 }}>
          <InputLabel>Фильтр по проекту</InputLabel>
          <Select
            value={filterProjectId}
            label="Фильтр по проекту"
            onChange={(e) => setFilterProjectId(e.target.value)}
            disabled={!projects.length}
          >
            <MenuItem value="">
              <em>Все проекты</em>
            </MenuItem>
            {projects.map(p => (
              <MenuItem key={p.id} value={p.id}>{p.name}</MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>
      
      {visibleTasks.length > 0 ? visibleTasks.map(task => (
        <Card key={task.id} sx={{ mb: 2 }}>
          <CardContent>
            <Box display="flex" justifyContent="space-between" alignItems="flex-start">
              <Box flex={1}>
                <Typography variant="h6" gutterBottom>{task.name}</Typography>
                {task.description && (
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    {task.description}
                  </Typography>
                )}
                {task.contractorName && (
                  <Typography variant="body2" color="primary" sx={{ mb: 1, cursor: 'pointer' }} onClick={() => navigate(`/contractors`)}>
                    <BusinessIcon sx={{ mr: 0.5, fontSize: 'small', verticalAlign: 'middle' }} />
                    {task.contractorName}
                  </Typography>
                )}
                {task.projectName && (
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1, cursor: 'pointer' }} onClick={() => navigate(`/projects`)}>
                    <WorkIcon sx={{ mr: 0.5, fontSize: 'small', verticalAlign: 'middle' }} />
                    {task.projectName}
                  </Typography>
                )}
                <Box display="flex" gap={1} flexWrap="wrap">
                  <Chip 
                    label={task.priority || 'medium'} 
                    color={getPriorityColor(task.priority || 'medium')} 
                    size="small" 
                  />
                  <Chip 
                    label={task.status || 'pending'} 
                    color={getStatusColor(task.status || 'pending')} 
                    size="small" 
                  />
                </Box>
              </Box>
              <Box display="flex" flexDirection="column" gap={1} alignItems="flex-end">
                <Box>
                  <IconButton aria-label="edit-task" onClick={() => handleOpenDialog(task)} size="small">
                    <EditIcon />
                  </IconButton>
                  <IconButton aria-label="delete-task" onClick={() => requestDelete(task.id)} size="small" color="error">
                    <DeleteIcon />
                  </IconButton>
                </Box>
                <TimeTrackingButton 
                  size="small"
                  variant="contained"
                  color="success"
                  startIcon={<MoneyIcon />}
                  buttonText="Начать учёт времени"
                />
              </Box>
            </Box>
          </CardContent>
        </Card>
      )) : <Typography>Задач пока нет.</Typography>}

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>
          {editingTask ? 'Редактировать задачу' : 'Новая задача'}
        </DialogTitle>
        <DialogContent>
          {contractors.length === 0 && (
            <Typography color="warning.main" sx={{ mb: 1 }}>
              Сначала добавьте контрагента, чтобы создать задачу.
            </Typography>
          )}
          <TextField
            autoFocus
            margin="dense"
            label="Название задачи"
            fullWidth
            variant="outlined"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            label="Описание"
            fullWidth
            variant="outlined"
            multiline
            rows={3}
            value={formData.description}
            onChange={(e) => setFormData({...formData, description: e.target.value})}
            sx={{ mb: 2 }}
          />
          
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Приоритет</InputLabel>
            <Select
              value={formData.priority}
              label="Приоритет"
              onChange={(e) => setFormData({...formData, priority: e.target.value})}
            >
              <MenuItem value="low">Низкий</MenuItem>
              <MenuItem value="medium">Средний</MenuItem>
              <MenuItem value="high">Высокий</MenuItem>
            </Select>
          </FormControl>
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Статус</InputLabel>
            <Select
              value={formData.status}
              label="Статус"
              onChange={(e) => setFormData({...formData, status: e.target.value})}
            >
              <MenuItem value="pending">Ожидает</MenuItem>
              <MenuItem value="in_progress">В работе</MenuItem>
              <MenuItem value="completed">Завершено</MenuItem>
            </Select>
          </FormControl>
          <FormControl fullWidth required error={!formData.contractorId}>
            <InputLabel>Контрагент</InputLabel>
            <Select
              value={formData.contractorId}
              label="Контрагент"
              onChange={(e) => handleContractorChange(e.target.value)}
              disabled={contractors.length === 0}
            >
              <MenuItem value="">
                <em>Не выбран</em>
              </MenuItem>
              {contractors.map(contractor => (
                <MenuItem key={contractor.id} value={contractor.id}>
                  {contractor.name}
                </MenuItem>
              ))}
            </Select>
            {!formData.contractorId && (
              <FormHelperText>Выберите контрагента</FormHelperText>
            )}
          </FormControl>
          {/* Проект (опционально) */}
          <FormControl fullWidth sx={{ mt: 2 }}>
            <InputLabel>Проект</InputLabel>
            <Select
              value={formData.projectId}
              label="Проект"
              onChange={(e) => {
                const pid = e.target.value as string;
                const p = projects.find(pr => pr.id === pid);
                setFormData({ ...formData, projectId: pid, projectName: p?.name || '' });
              }}
              disabled={!formData.contractorId}
            >
              <MenuItem value="">
                <em>Не выбран</em>
              </MenuItem>
              {projects.filter(p => p.contractorId === formData.contractorId).map(p => (
                <MenuItem key={p.id} value={p.id}>{p.name}</MenuItem>
              ))}
            </Select>
            <FormHelperText>Проект можно выбрать после выбора контрагента</FormHelperText>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} disabled={submitting}>Отмена</Button>
          <Button onClick={handleSubmit} variant="contained" disabled={isSaveDisabled}>
            {submitting ? 'Сохранение...' : (editingTask ? 'Сохранить' : 'Создать')}
          </Button>
        </DialogActions>
      </Dialog>

      <ConfirmDialog
        open={confirm.open}
        message="Удалить эту задачу?"
        confirmText="Удалить"
        onConfirm={confirmDelete}
        onClose={() => setConfirm({ open: false })}
      />

      <Notification
        open={notification.open}
        message={notification.message}
        severity={notification.severity}
        onClose={() => setNotification({ ...notification, open: false })}
      />
    
      <Dialog open={startWorkData.open} onClose={() => setStartWorkData({ open: false, task: null, file: null, location: null })}
        fullWidth
        maxWidth="sm"
        PaperProps={{
          sx: {
            m: { xs: 2, sm: 3 },
            width: { xs: 'calc(100% - 32px)', sm: 'auto' }
          }
        }}>
        <DialogTitle>Начать работу по задаче</DialogTitle>
        <DialogContent>
          <Box display="flex" flexDirection="column" gap={2}>
            <Typography variant="subtitle1" fontWeight="medium">Задача: {startWorkData.task?.name}</Typography>
            
            <Button component="label" variant="contained" fullWidth>
              {startWorkData.file ? 'Изменить фото' : 'Загрузить фото'}
              <input type="file" accept="image/*" capture="environment" hidden onChange={(e) => setStartWorkData(prev => ({ ...prev, file: e.target.files?.[0] || null }))} />
            </Button>
            {startWorkData.file && (
              <Typography variant="body2" color="text.secondary">
                Выбрано: {startWorkData.file.name}
              </Typography>
            )}
            
            <Button 
              variant="outlined" 
              fullWidth
              onClick={() => {
                navigator.geolocation.getCurrentPosition(
                  pos => setStartWorkData(prev => ({ ...prev, location: pos })),
                  err => setNotification({ open: true, message: 'Не удалось получить геолокацию', severity: 'error' })
                );
              }}
              color={startWorkData.location ? 'success' : 'primary'}
            >
              {startWorkData.location ? '✓ Геолокация получена' : 'Получить геолокацию'}
            </Button>
            {startWorkData.location && (
              <Typography variant="caption" color="text.secondary">
                Координаты: {startWorkData.location.coords.latitude.toFixed(6)}, {startWorkData.location.coords.longitude.toFixed(6)}
              </Typography>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setStartWorkData({ open: false, task: null, file: null, location: null })}>Отмена</Button>
          <Button onClick={handleStartWork} disabled={!startWorkData.file}>Начать</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default TasksPage;