import React, { useState, useEffect } from 'react';
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
  Typography,
  Alert,
  Box,
  CircularProgress,
  Stepper,
  Step,
  StepLabel,
} from '@mui/material';
import {
  PlayArrow as StartIcon,
  AttachMoney as MoneyIcon,
  Check as CheckIcon,
} from '@mui/icons-material';
import { useAuth } from '../auth/AuthContext';
import { useTimeTracking } from '../contexts/TimeTrackingContext';
import { getProjectsStream, Project } from '../api/projectApi';
import { getTasksStream, Task } from '../api/taskApi';
import type { ButtonProps as MUIButtonProps } from '@mui/material/Button';

interface TimeTrackingButtonProps extends Omit<MUIButtonProps, 'children'> {
  buttonText?: string;
}

const TimeTrackingButton: React.FC<TimeTrackingButtonProps> = ({
  variant = 'contained',
  size = 'small',
  fullWidth = false,
  color = 'success',
  startIcon = <MoneyIcon />,
  buttonText = 'Начать учёт времени',
  onClick,
  disabled,
  ...otherButtonProps
}) => {
  const { currentUser } = useAuth();
  const { isWorking, startWork } = useTimeTracking();
  
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [projects, setProjects] = useState<Project[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [activeStep, setActiveStep] = useState(0);
  const [error, setError] = useState<string | null>(null);

  // Load projects and tasks
  useEffect(() => {
    if (!currentUser || !open) return;

    const unsubProjects = getProjectsStream(currentUser.uid, setProjects);
    const unsubTasks = getTasksStream(currentUser.uid, setTasks);

    return () => {
      unsubProjects && unsubProjects();
      unsubTasks && unsubTasks();
    };
  }, [currentUser, open]);

  const handleOpen = () => {
    if (isWorking) {
      setError('Уже идет учет времени. Завершите текущую работу.');
      return;
    }
    setOpen(true);
    setActiveStep(0);
    setSelectedProject(null);
    setSelectedTask(null);
    setError(null);
  };

  const handleClose = () => {
    if (loading) return;
    setOpen(false);
    setError(null);
  };

  const handleSelectProject = (project: Project) => {
    setSelectedProject(project);
    setActiveStep(1);
    setError(null);
  };

  const handleSelectTask = (task: Task) => {
    setSelectedTask(task);
    setActiveStep(2);
    setError(null);
  };

  const handleStart = async () => {
    if (!selectedProject || !selectedTask) return;

    setLoading(true);
    setError(null);

    try {
      await startWork(
        selectedProject.id,
        selectedProject.name,
        selectedTask.id,
        selectedTask.name
      );
      
      // Success
      setOpen(false);
      setActiveStep(0);
      setSelectedProject(null);
      setSelectedTask(null);
    } catch (err: any) {
      console.error('Failed to start work:', err);
      setError(err.message || 'Ошибка при начале работы');
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    if (activeStep > 0) {
      setActiveStep(activeStep - 1);
      if (activeStep === 2) setSelectedTask(null);
      if (activeStep === 1) setSelectedProject(null);
    }
    setError(null);
  };

  const activeProjects = projects.filter(p => p.status === 'active');
  const projectTasks = selectedProject
    ? tasks.filter(t => t.projectId === selectedProject.id && t.status !== 'completed')
    : [];

  const steps = ['Выберите проект', 'Выберите задачу', 'Подтверждение'];

  return (
    <>
      <Button
        variant={variant}
        color={color}
        size={size}
        fullWidth={fullWidth}
        startIcon={startIcon}
        onClick={(event) => {
          onClick?.(event);
          handleOpen();
        }}
        disabled={isWorking || Boolean(disabled)}
        {...otherButtonProps}
      >
        {isWorking ? 'Идет учет времени' : buttonText}
      </Button>

      <Dialog
        open={open}
        onClose={handleClose}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          sx: { minHeight: '400px' }
        }}
      >
        <DialogTitle>
          Начать учет времени
          <Stepper activeStep={activeStep} sx={{ mt: 2 }}>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
        </DialogTitle>

        <DialogContent>
          {error && (
            <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
              {error}
            </Alert>
          )}

          {/* Step 0: Select Project */}
          {activeStep === 0 && (
            <Box>
              {activeProjects.length === 0 ? (
                <Alert severity="info">
                  Нет активных проектов. Создайте проект для начала работы.
                </Alert>
              ) : (
                <>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    Выберите проект для работы:
                  </Typography>
                  <List>
                    {activeProjects.map((project) => (
                      <ListItem key={project.id} disablePadding sx={{ mb: 1 }}>
                        <ListItemButton
                          onClick={() => handleSelectProject(project)}
                          sx={{
                            border: '1px solid',
                            borderColor: 'divider',
                            borderRadius: 1,
                            '&:hover': {
                              backgroundColor: 'action.hover',
                            },
                          }}
                        >
                          <ListItemText
                            primary={project.name}
                            secondary={project.contractorName || 'Без заказчика'}
                          />
                        </ListItemButton>
                      </ListItem>
                    ))}
                  </List>
                </>
              )}
            </Box>
          )}

          {/* Step 1: Select Task */}
          {activeStep === 1 && selectedProject && (
            <Box>
              <Alert severity="info" sx={{ mb: 2 }}>
                Проект: <strong>{selectedProject.name}</strong>
              </Alert>
              
              {projectTasks.length === 0 ? (
                <Alert severity="warning">
                  В этом проекте нет активных задач. Создайте задачу для начала работы.
                </Alert>
              ) : (
                <>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    Выберите задачу:
                  </Typography>
                  <List>
                    {projectTasks.map((task) => (
                      <ListItem key={task.id} disablePadding sx={{ mb: 1 }}>
                        <ListItemButton
                          onClick={() => handleSelectTask(task)}
                          sx={{
                            border: '1px solid',
                            borderColor: 'divider',
                            borderRadius: 1,
                            '&:hover': {
                              backgroundColor: 'action.hover',
                            },
                          }}
                        >
                          <ListItemText
                            primary={task.name}
                            secondary={task.description || 'Без описания'}
                          />
                        </ListItemButton>
                      </ListItem>
                    ))}
                  </List>
                </>
              )}
            </Box>
          )}

          {/* Step 2: Confirmation */}
          {activeStep === 2 && selectedProject && selectedTask && (
            <Box>
              <Alert severity="success" icon={<CheckIcon />} sx={{ mb: 3 }}>
                Готово к началу работы!
              </Alert>
              
              <Box sx={{ p: 2, bgcolor: 'background.paper', borderRadius: 1, mb: 2 }}>
                <Typography variant="subtitle2" color="text.secondary">
                  Проект
                </Typography>
                <Typography variant="body1" sx={{ mb: 2 }}>
                  {selectedProject.name}
                </Typography>
                
                <Typography variant="subtitle2" color="text.secondary">
                  Задача
                </Typography>
                <Typography variant="body1">
                  {selectedTask.name}
                </Typography>
              </Box>

              <Alert severity="info">
                После начала работы будет запущен таймер учета времени. 
                Вы сможете видеть активную сессию на главной странице.
              </Alert>
            </Box>
          )}
        </DialogContent>

        <DialogActions>
          {activeStep > 0 && (
            <Button onClick={handleBack} disabled={loading}>
              Назад
            </Button>
          )}
          <Button onClick={handleClose} disabled={loading}>
            Отмена
          </Button>
          {activeStep === 2 && (
            <Button
              onClick={handleStart}
              variant="contained"
              color="success"
              disabled={loading}
              startIcon={loading ? <CircularProgress size={20} /> : <StartIcon />}
            >
              {loading ? 'Запуск...' : 'Начать работу'}
            </Button>
          )}
        </DialogActions>
      </Dialog>
    </>
  );
};

export default TimeTrackingButton;
