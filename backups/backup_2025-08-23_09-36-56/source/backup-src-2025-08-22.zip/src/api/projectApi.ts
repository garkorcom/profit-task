// Модуль работы с проектами (CRUD и стриминг из Firestore)
// Структура хранения: users/{userId}/projects/{projectId}
import { db } from '../firebase/firebase';
import { collection, onSnapshot, query, orderBy, addDoc, updateDoc, deleteDoc, doc, serverTimestamp, where } from 'firebase/firestore';

export type ProjectStatus = 'planned' | 'active' | 'paused' | 'completed';

export interface Project {
  id: string;
  name: string;
  code?: string;
  description?: string;
  status?: ProjectStatus;
  startDate?: string; // ISO строка или краткий формат, для простоты UI
  endDate?: string;
  budget?: number;
  
  // Новые поля
  priority?: 'low' | 'medium' | 'high' | 'critical'; // Приоритет
  type?: string; // Тип проекта (например, "Разработка", "Маркетинг")
  
  // Связь с клиентом
  contractorId?: string;
  contractorName?: string;
  
  // Связь с командой
  managerId?: string;    // ID руководителя проекта
  managerName?: string;  // Имя руководителя
  team?: {
    id: string;        // ID сотрудника
    name: string;      // Имя
    role: string;      // Роль в проекте
  }[];
  
  // Денормализованные счетчики
  estimatesCount?: number; 
  tasksCount?: number;
  
  // Финансы
  actualCost?: number; // Фактическая стоимость
  
  createdAt?: any;
  updatedAt?: any;
}

// Поток проектов пользователя
export const getProjectsStream = (userId: string, callback: (projects: Project[]) => void) => {
  const projectsPath = `users/${userId}/projects`;
  const q = query(collection(db, projectsPath), orderBy('name', 'asc'));
  return onSnapshot(q, (snapshot) => {
    const projects = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Project[];
    callback(projects);
  });
};

// Создание проекта
export const addProject = async (userId: string, projectData: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>) => {
  const projectsPath = `users/${userId}/projects`;
  // Firestore не принимает поля со значением undefined. Удаляем такие поля перед записью
  const sanitizedData = Object.fromEntries(
    Object.entries(projectData as Record<string, any>).filter(([, value]) => value !== undefined)
  );
  const withTimestamps = {
    ...sanitizedData,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  };
  const ref = await addDoc(collection(db, projectsPath), withTimestamps);
  return ref.id;
};

// Обновление проекта
export const updateProject = async (userId: string, projectId: string, updates: Partial<Project>) => {
  const projectRef = doc(db, `users/${userId}/projects`, projectId);
  // Удаляем undefined, иначе updateDoc выбросит ошибку
  const sanitizedUpdates = Object.fromEntries(
    Object.entries(updates as Record<string, any>).filter(([, value]) => value !== undefined)
  );
  await updateDoc(projectRef, { ...sanitizedUpdates, updatedAt: serverTimestamp() });
};

// Удаление проекта
export const deleteProject = async (userId: string, projectId: string) => {
  const projectRef = doc(db, `users/${userId}/projects`, projectId);
  await deleteDoc(projectRef);
};

// Get a real-time stream for a single project
export const getProjectStream = (userId: string, projectId: string, callback: (project: Project | null) => void) => {
  const projectPath = `users/${userId}/projects/${projectId}`;
  return onSnapshot(doc(db, projectPath), (snapshot) => {
    if (snapshot.exists()) {
      callback({ id: snapshot.id, ...snapshot.data() } as Project);
    } else {
      callback(null);
    }
  });
};

/**
 * Получить поток активных проектов (ограниченный лимит)
 */
export const getActiveProjectsStream = (userId: string, limitCount: number = 5, callback: (projects: Project[]) => void) => {
  const projectsPath = `users/${userId}/projects`;
  // Минимизируем требования к индексам: только where, сортировку и лимит делаем на клиенте
  const q = query(
    collection(db, projectsPath),
    where('status', '==', 'active')
  );
  return onSnapshot(q, (snapshot) => {
    const projects = (snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Project[])
      .sort((a, b) => (a.endDate || '').localeCompare(b.endDate || ''))
      .slice(0, Math.max(1, limitCount));
    callback(projects);
  });
};


